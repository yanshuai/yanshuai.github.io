package example;

public class MySQLBo {
    public void connect() {
        System.out.println("connecting to mysql...");
    }

    public void execute(String sql) {
        System.out.println(String.format("executing sql %s", sql));
    }

    public void query(String sql) throws InterruptedException {
        System.out.println("begin query");
        Thread.sleep(5000);
        System.out.println("end query");
    }

    public void close() {
        System.out.println("close connection...");
    }
}
