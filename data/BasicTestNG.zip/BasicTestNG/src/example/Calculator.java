package example;

public class Calculator {
    public double division(int a, int b) {
        System.out.println(String.format("calculator %d/%d", a, b));
        if (0 == b) {
            throw new IllegalArgumentException("除数不能为0");
        }
        return a / b;
    }
}
