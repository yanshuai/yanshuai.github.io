package example;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class CalculatorTest {

    public CalculatorTest() {
        System.out.println("CalculatorTest()");
    }

    @Test
    public void testNormalDivision() {
        Assert.assertTrue(Math.abs(c.division(4, 2) - 2.0) < Double.MIN_VALUE);
    }

    @Test
    public void testNormalDivision2() {
        Assert.assertTrue(Math.abs(c.division(8, 4) - 2.0) < Double.MIN_VALUE);
    }

    @Test(expectedExceptions = IllegalArgumentException.class)
    public void testIllegalDivision() {
        c.division(4, 0);
    }

    @Test(enabled = false)
    public void testUnNormalDivision() {
        Assert.assertTrue(Math.abs(c.division(1, 2) - 0.5) < Double.MIN_VALUE);
    }

    @Test(dataProvider = "provideNumbers")
    public void testDivisionWithDataProvider(int a, int b) {
        Assert.assertTrue(Math.abs(c.division(a, b) - a / b) < Double.MIN_VALUE);
    }

    @DataProvider(name = "provideNumbers")
    public Object[][] provideData() {

        return new Object[][]{
            {10, 20},
            {110, 100},
            {200, 210}
        };
    }

    private final Calculator c = new Calculator();
}
