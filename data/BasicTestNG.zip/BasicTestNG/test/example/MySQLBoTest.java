package example;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MySQLBoTest {

    public MySQLBoTest() {
        System.out.println("MySQLBoTest()");
    }

    @BeforeClass
    public void setUpBeforeClass() {
        mysqlBo.connect();
        System.out.println(System.currentTimeMillis());
    }

    @Test
    public void b() {
        mysqlBo.execute("b");
    }

    @Test
    public void a() {
        mysqlBo.execute("a");
    }

    @Test
    public void c() {
        mysqlBo.execute("c");
    }

    @Test(timeOut = 30000)
    public void aa() throws Exception {
        mysqlBo.query("aa");
    }

    @AfterClass(alwaysRun = true)
    public void tearDownAfterClass() {
        System.out.println(System.currentTimeMillis());
        mysqlBo.close();
    }

    private final MySQLBo mysqlBo = new MySQLBo();
}
