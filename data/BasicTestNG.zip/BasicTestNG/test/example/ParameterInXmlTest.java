package example;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ParameterInXmlTest {
    @Test
    @Parameters({"a", "b"})
    public void test(String c, int d) {
        System.out.println(String.format("c = %s", c));
        System.out.println(String.format("d = %d", d));
    }
}
